#!/usr/bin/python
# -*- coding: utf-8 -*-
import os, platform
import xbmc
import xbmcaddon
import xbmcgui, xbmcvfs
import YDStreamUtils
import YDStreamExtractor
import time

def getFFMPEGVersion():
    osname = platform.system() #os.name
    #windows
    if osname == 'Windows':
        return 'ffmpeg.exe'
    #linux
    elif osname == 'Linux':
        return 'ffmpeg'
#rpi_preinstalled='/usr/local/bin/ffmpeg'

addon = xbmcaddon.Addon()    
translation = addon.getLocalizedString
folder=addon.getSetting("folder")
home = xbmcvfs.translatePath(addon.getAddonInfo('path'))
#ffmpgfile=addon.getSetting("ffmpgfile")
ffmpgfile=os.path.join(home, 'resources', getFFMPEGVersion())
#warning=addon.getSetting("warning")
warning=True



def debug(content):
    log(content, xbmc.LOGINFO) #xbmc.LOGDEBUG)
    
def notice(content):
    log(content, xbmc.LOGINFO)

def log(msg, level=xbmc.LOGINFO):
    addon = xbmcaddon.Addon()
    addonID = addon.getAddonInfo('id')
    xbmc.log('%s: %s' % (addonID, msg), level) 

def downloadyoutube(file,ffdir=""):
 debug("Start with download youtube-dl")
 # if FFmpeg is defined use it also at youtube-dl
 if not ffdir=="": 
    YDStreamExtractor.overrideParam('ffmpeg_location',ffdir)
 
 # download video
 YDStreamExtractor.overrideParam('preferedformat',"avi")  
 vid = YDStreamExtractor.getVideoInfo(file,quality=2)  
 with YDStreamUtils.DownloadProgress() as prog: # this creates a progress dialog interface ready to use
    try:
        YDStreamExtractor.setOutputCallback(prog)
        result = YDStreamExtractor.downloadVideo(vid,folder)
        if result:            
            full_path_to_file = result.filepath
        elif result.status != 'canceled':            
            error_message = result.message
    finally:
        YDStreamExtractor.setOutputCallback(None)
        
def downloadffmpg(file,name):    
    debug("Start download with ffmpg")
    import ffmpy
    import subprocess
    name=name.replace(" ","_").replace(":","")
    name=name[0:50]+".mp4"  
    name=os.path.join(folder,name)   
    ff = ffmpy.FFmpeg(executable=ffmpgfile, inputs={file: None},outputs={name: '-codec copy'})    
    erg=ff.cmd
    debug(erg)
    try:
        dialog=xbmcgui.DialogProgress()
        # download started
        dialog.create(translation(30002))        
        ret=ff.run(stdout=subprocess.PIPE)
        debug("ffmpg is running...")
        debug(translation(30002))
        dialog.close()
        dialog2 = xbmcgui.Dialog()                
        nr=dialog2.ok(translation(30003), translation(30004))
    except:
      dialog.close()
      dialog = xbmcgui.Dialog()
      nr=dialog.ok(translation(30005), translation(30006))
      kodi_player.play(path,listitem)
      time.sleep(5)
      ffdir,fffile=os.path.split(ffmpgfile)
      debug("FFDIR :"+ffdir)
      downloadyoutube(file,ffdir=ffdir)  
    
#MAIN    
# warning about abuse
if warning=="false":
    dialog = xbmcgui.Dialog()
    erg=dialog.yesno(translation(30007), translation(30008),translation(30009),translation(30010))
    if erg==1:
       addon.setSetting("warning","true")
    else:
      quit()    

# read selected infolabel      
path = xbmc.getInfoLabel('ListItem.FileNameAndPath')
title = xbmc.getInfoLabel('ListItem.Title')
listitem = xbmcgui.ListItem(path=path)
listitem.setInfo(type="Video", infoLabels={"Title": title})

# start video
kodi_player = xbmc.Player()
kodi_player.play(path,listitem)
time.sleep(10) 
videoda=0

# until the first file is played read file
while videoda==0 :
    try:
        file=kodi_player.getPlayingFile()
        debug("-----> "+file)
        if not file=="":
            videoda=1
    except:
        pass 
# kill header fields        
file=file.split("|")[0]      

# use FFmpeg or youtube-dl
if not ffmpgfile=="":
   kodi_player.stop()
   downloadffmpg(file,title)  
   debug("Stop download with ffmpg")
else:
   downloadyoutube(file)
